﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DayCount : Singleton<DayCount>
{
    public int Day = 1;
}
